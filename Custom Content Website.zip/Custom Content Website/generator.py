from transformers import pipeline

class ContentGenerator:
    def __init__(self):
        self.generator = pipeline('text-generation', model='gpt2')

    def generate_marketing_copy(self, prompt, max_length=100):
        outputs = self.generator(prompt, max_length=max_length, num_return_sequences=1)
        return outputs[0]['generated_text']

