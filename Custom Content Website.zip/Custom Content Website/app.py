from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    generated_text = ''
    if request.method == 'POST':
        product = request.form['product']
        audience = request.form['audience']
        tone = request.form['tone']
        generated_text = f"Introducing {product} – the perfect choice for {audience}! Enjoy a {tone.lower()} experience like no other."
    return render_template('index.html', output=generated_text)

if __name__ == '__main__':
    app.run(debug=True)
